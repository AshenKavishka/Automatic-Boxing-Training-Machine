/*
 * 
 *
 * Servo_Motor.c
 * 
 */ 

#ifndef F_CPU
#define F_CPU 16000000UL // 16 MHz clock speed
#endif

#include <avr/io.h>
#include <util/delay.h>

int main(void)
{
	DDRB = 0x08; //Makes RB3 output pin
	PORTB = 0x00;
	DDRD = 0xB0; //Makes RD4,RD5 and RD7 output pins
	PORTD = 0x00;
	while(1)
	{
		//Rotate Motor 1 to 0 degree
		PORTB = 0x08;
		_delay_us(1000);
		PORTB = 0x00;

		_delay_ms(200);

		//Rotate Motor 1 to 90 degree
		PORTB = 0x08;
		_delay_us(1500);
		PORTB = 0x00;

		_delay_ms(200);
		
		//Rotate Motor 4 to 0 degree
		PORTD = 0x80;
		_delay_us(1000);
		PORTD = 0x00;

		_delay_ms(200);

		//Rotate Motor 4 to 90 degree
		PORTD = 0x80;
		_delay_us(1500);
		PORTD = 0x00;

		_delay_ms(200);
		
		//Rotate Motor 2 to 0 degree
		PORTD = 0x10;
		_delay_us(1000);
		PORTD = 0x00;

		_delay_ms(200);

		//Rotate Motor 2 to 90 degree
		PORTD = 0x10;
		_delay_us(1500);
		PORTD = 0x00;

		_delay_ms(200);
		
		//Rotate Motor 3 to 0 degree
		PORTD = 0x20;
		_delay_us(1000);
		PORTD = 0x00;

		_delay_ms(200);

		//Rotate Motor 3 to 90 degree
		PORTD = 0x20;
		_delay_us(1500);
		PORTD = 0x00;

		_delay_ms(200);		
	}
}
